package com.example.lucianodsepulveda.pasajerito;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FavoritosActivity extends FragmentActivity implements View.OnClickListener{

    //cambiar nombres variables
    Button btnScanBarcode;
    ListView lista;
    ArrayAdapter<String> adaptador;
    TextView tvPrueba;
    RecyclerView rv;
    RecyclerViewAdapter adapter;
    RecyclerView.LayoutManager layoutManager;
    SharedPreferences preferences;
    SharedPreferences.Editor editor2;
    SwipeRefreshLayout swipeRefreshLayout;
    TextView tvNet;
    TextView tvAccess;

    List<Data> listData = new ArrayList<Data>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barcode);
        initViews();
    }


    public void initViews() {
        btnScanBarcode = findViewById(R.id.btnScanBarcode);
        btnScanBarcode.setOnClickListener(this);
        tvPrueba = (TextView) findViewById(R.id.tvPrueba);
        lista = (ListView) findViewById(R.id.lvFav);
        adaptador = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);

        tvNet = (TextView)findViewById(R.id.tv_net);
        tvAccess = (TextView)findViewById(R.id.tv_access);

        boolean redHab = isOnlineNet();
        if(redHab) {
            tvNet.setText( "Red habilitada" );
        }else{
            tvNet.setText( "Red deshabilitada" );
        }

        boolean accesoInter = isNetDisponible();
        if(accesoInter) {
            tvAccess.setText( "Conectado a internet" );
        }else{
            tvAccess.setText("Sin conexion a internet");
        }

        preferences = getApplicationContext().getSharedPreferences("Codigos", Context.MODE_PRIVATE);
        editor2 = preferences.edit();
        Map<String, ?> allEntries = preferences.getAll();
        for(Map.Entry<String,?> entry : allEntries.entrySet()){
            adaptador.add(entry.getValue().toString());
            listData.add(new Data(entry.getKey()));
        }

        rv = (RecyclerView) findViewById(R.id.rv);
        rv.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(layoutManager);

        final MainFragment fragment = (MainFragment) getFragmentManager().findFragmentById(R.id.main_fragment) ;

        adapter = new RecyclerViewAdapter(listData,this,fragment);
        rv.setAdapter(adapter);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper( new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT){

            // esto es si se quiere mover los elementos hacia arriba y abajo
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(final RecyclerView.ViewHolder viewHolder, int direction) {

                AlertDialog.Builder builder = new AlertDialog.Builder(FavoritosActivity.this);
                builder.setTitle("Eliminar codigo Qr");
                builder.setMessage("Esta seguro que desea eliminar el codigo Qr de favoritos?");
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        int pos = viewHolder.getAdapterPosition();
                        Data aux = listData.get(pos);
                        SharedPreferences.Editor myEditor = preferences.edit();
                        myEditor.remove(aux.getCodigo());
                        myEditor.commit();
                        listData.remove(pos);
                        adapter.notifyDataSetChanged();
                        Toast t10 = Toast.makeText(getApplicationContext(),aux.getCodigo()+" eliminado!",Toast.LENGTH_SHORT);
                        t10.show();
                    }
                });

                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        adapter.notifyDataSetChanged();
                    }
                });

                Dialog dialog = builder.create();
                dialog.show();

            }
        });

        itemTouchHelper.attachToRecyclerView(rv);

        lista.setAdapter(adaptador);
    }

    // red habilitada
    public boolean isNetDisponible(){
        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo actNetInfo = connectivityManager.getActiveNetworkInfo();
        return (actNetInfo != null && actNetInfo.isConnected());
    }

    // si hay acceso a internet
    public Boolean isOnlineNet(){

        Process p = null;
        try {
            p = Runtime.getRuntime().exec("ping -c 1 www.google.es");
            int val = p.waitFor();
            boolean reachable = (val == 0);
            return reachable;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnScanBarcode:
                startActivity(new Intent(FavoritosActivity.this, ScannerQRCodeActivity.class));
                finish();
                break;
        }
    }

    public List<Data> getListData() {
        return listData;
    }

    public void setListData(List<Data> listData) {
        this.listData = listData;
    }

}
